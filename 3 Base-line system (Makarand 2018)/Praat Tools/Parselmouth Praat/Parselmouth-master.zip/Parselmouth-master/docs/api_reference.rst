API Reference
=============

.. automodule:: parselmouth
    :members:
    :special-members:
    :undoc-members:
    :show-inheritance:
    :exclude-members: __weakref__, __doc__, __module__, __dict__, __members__, __getstate__, __setstate__


.. automodule:: parselmouth.praat
    :members:
    :special-members:
    :undoc-members:
    :show-inheritance:
    :exclude-members: __weakref__, __doc__, __module__, __dict__, __members__, __getstate__, __setstate__

